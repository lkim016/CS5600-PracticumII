#!/bin/bash
make all

program=./rfs
# TEST: test the command args in client - 2, 3,
cmd1=eval $program WRITE
cmd2=eval $program WRITE "data/file1.txt"
# # TEST: edge case - 5
# # TEST: WRITE command with first and second filepath given (happy)
cmd3=eval $program WRITE "data/file1.txt data/test1.txt"
# # TEST: WRITE command with first filepath and second omitted (edge)
cmd4=eval $program WRITE data/file1.txt
# # TEST: WRITE command with first filepath being the first file we wrote out to remote and second omitted (edge)
cmd5=eval $program GET data/test1.txt

# TEST STOP command (happy)
# cmd3=eval $program STOP
# echo "exit status = " $?


# i=1
# while [$i -le 4]; do
#     cmd$i # &
#     echo "Process: $i"
# done