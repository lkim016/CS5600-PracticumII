# Instructions

### References
[^1]  
[^2]  
[^3]  
[^4]  
[^5]

[^1]: "TCP/IP Protocol Design: Message Framing." codeproject, 20 Jun 2009. https://www.codeproject.com/articles/TCP-IP-Protocol-Design-Message-Framing#comments-section. Accessed: 2025-12-02.  
[^2]: "fseek() in C." GeeksforGeeks, 02 Aug 2025. https://www.geeksforgeeks.org/cpp/fseek-in-c-with-example/. Accessed: 2025-12-02.  
[^3]: "Socket Programming using TCP in C." SoftPrayog, 03 Oct 2018. https://www.softprayog.in/programming/network-socket-programming-using-tcp-in-c. Accessed: 2025-12-02.  
[^4]: "Socket Programming in C." GeeksforGeeks, 07 Aug 2025. https://www.geeksforgeeks.org/c/socket-programming-cc/. Accessed: 2025-12-02.  
[^5]: "Handling multiple clients on server with multithreading using Socket Programming in C/C++." GeeksforGeeks, 23 Jul 2025. https://www.geeksforgeeks.org/cpp/  

# TODO:
1. check for file extension using Method 1: Using the `Path.GetExtension()` Method - https://hatchjs.com/c-get-file-extension/
